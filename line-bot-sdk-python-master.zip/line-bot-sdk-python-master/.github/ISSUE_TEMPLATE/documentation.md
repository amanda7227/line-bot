---
name: "Documentation"
about: Report an issue related to README.md or https://line-bot-sdk-python.readthedocs.io
labels: ''

---

## Documentation
<!-- Did you find a mistake, or something that needs clarification? -->
