# Simple Server Echo

Sample echo-bot using [wsgiref.simple_server](https://docs.python.org/3/library/wsgiref.html)

## Getting started

```
$ export LINE_CHANNEL_SECRET=YOUR_LINE_CHANNEL_SECRET
$ export LINE_CHANNEL_ACCESS_TOKEN=YOUR_LINE_CHANNEL_ACCESS_TOKEN

$ pip install -r requirements.txt

$ python app.py
```
